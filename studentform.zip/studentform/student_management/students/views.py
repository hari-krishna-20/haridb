
from django.shortcuts import render
from . import  urls
from django.http import HttpResponse
from django.template import loader

def student_login(request):
    template = loader.get_template('login.html')
    return HttpResponse(template.render())
