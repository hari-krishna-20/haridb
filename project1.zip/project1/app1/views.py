
from django.urls import reverse
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from .models import newApp
# Create your views here.
def index(request):
    return HttpResponse('Hello World')
def htmlex(request):
    members=newApp.objects.all().values()
    templates=loader.get_template('index.html')
    context={
        'members':members,
    }
    return HttpResponse(templates.render(context,request))
def name(request):
    members=newApp.objects.all().values()
    output=""
    for x in members:
        output+=x['firstname']+" "+x["lastname"]+","
    return HttpResponse(output) 
def add(request):
    templates=loader.get_template('add.html')
    return HttpResponse(templates.render({},request))
def addrecord(request):
    x=request.POST["first"]
    y=request.POST["last"]
    member=newApp(firstname=x,lastname=y)
    member.save()
    return HttpResponseRedirect(reverse('htmlex'))

def delete(request):
    new=newApp.objects.get(id=id)
    new.delete()
    return HttpResponseRedirect(reverse('htmlex'))