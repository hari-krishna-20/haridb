from django.db import models
from django.forms import DateField

# Create your models here.
class newApp(models.Model):
    firstname=models.CharField(max_length=255)
    lastname=models.CharField(max_length=255)

