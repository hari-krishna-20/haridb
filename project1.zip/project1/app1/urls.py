from django.urls import path
from . import views
urlpatterns=[
    path('a/',views.index,name='index'),
    path('htmlex/',views.htmlex,name='htmlex'),
    path('c/',views.name,name='name'),
    path('htmlex/add/',views.add,name='add'),
    path('htmlex/add/addrecord/',views.addrecord,name='addrecord'),
    path('htmlex/delete/<int:id>',views.delete,name='delete'),
]