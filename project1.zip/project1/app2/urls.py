from django.urls import path
from . import views
urlpatterns=[
    path('Order/',views.Orders,name='Orders'),
    path('Book/',views.Books,name='Books'),
    path('Student/',views.Students,name='Students'),
    path('Product/',views.Products,name='Products'),
]