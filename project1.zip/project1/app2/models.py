from django.db import models
# Create your models here.

class Book(models.Model):
    title=models.CharField(max_length=100)
    author=models.CharField(max_length=100)
    date=models.DateField()
    price=models.DecimalField(max_digits=8,decimal_places=2)
    def is_expensive(self):
        if int(self.price)>200:
            return True
        else:
            return False
class Student(models.Model):
    name=models.CharField(max_length=100)
    age=models.IntegerField()
    grade=models.CharField(max_length=10)
    enrolled=models.BooleanField()
    def is_passing(self):
        if self.grade in ('A','B','C'):
            return "PASS" 
        else:
            return "FAIL"

class Product(models.Model):
    name=models.CharField(max_length=100)
    description=models.TextField()
    price=models.DecimalField(max_digits=8,decimal_places=2)
    quantity=models.PositiveIntegerField()
    def calculate_total_cost(self):
        return self.price*self.quantity
    
class Order(models.Model):
    order_number = models.CharField(max_length=20)
    customer_name = models.CharField(max_length=100)
    order_date = models.DateField()
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)

    def is_high_value(self):
        return self.total_amount > 1000