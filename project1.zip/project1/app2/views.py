from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from django.shortcuts import render
from .models import Order,Book,Student,Product

def Orders(request):
    orders = Order.objects.all()
    return render(request,'Order.html',{'orders': orders})

def Books(request):
    books=Book.objects.all()
    return render(request,'Book.html',{'books':books})

def Students(request):
    students=Student.objects.all()
    return render(request,'Student.html',{'students':students})

def Products(request):
    products=Product.objects.all()
    return render(request,'Product.html',{'products':products})

def product_detail(request):
    return 