from django.db import models
class studentdb(models.Model):
    name = models.CharField(max_length = 100)
    age = models.IntegerField()
    grade = models.CharField(max_length = 10)
    isenrolled = models.BooleanField()
    def is_passing(self):
        if self.grade >= "C":
            return True
        return False

# Create your models here.
