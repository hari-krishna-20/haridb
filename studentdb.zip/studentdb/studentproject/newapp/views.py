from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import studentdb

def student1(request):
    mystudent = studentdb.objects.all().values()
    return render(request,"index.html",{"student":mystudent})




# Create your views here.
